for carousel i have use Slick library 


Break Points 
- Mobile: 375px
- Tablet: 768px
- Desktop: 1600px